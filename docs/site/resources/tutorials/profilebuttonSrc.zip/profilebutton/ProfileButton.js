/*global define*/
define([
    'jscore/core',
    './ProfileButtonView'
], function (core, View) {
    'use strict';

    return core.Region.extend({
        name: "Profile",
        order: "200",
        View: View,

        onStart: function (options) {
            this.options = options || {};
            this.addHandler();
        },

        addHandler: function () {
            var button = this.view.getButton();
            button.addEventHandler('click', function () {
                var panel = this.view.getPanel();
                var display = (panel.getStyle('display') === 'block') ? 'none' : 'block';
                panel.setStyle('display', display);
            }.bind(this));
        }
    });
});
