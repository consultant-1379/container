/*global define*/
define([
    'jscore/core',
    'text!./profileButton.html',
    'styles!./profileButton.less'
], function (core, template, styles) {
    'use strict';

    return core.View.extend({

        getTemplate: function () {
            return template;
        },
        getStyle: function () {
            return styles;
        },
        getButton: function () {
            return this.getElement().find(".eaContainer-ProfileButton-button");
        },
        getPanel: function () {
            return this.getElement().find(".eaContainer-ProfileButton-panel");
        }
    });

});
